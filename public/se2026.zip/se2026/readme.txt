==================================================================================================

DESCRIPTION:

This (SQE Creative Business website Template) is a clean, modern and well crafted responsive template designed for 
Business Startups, Agencies, Small Business, Desingers, etc.The clean layout helps this professional template to stand out.
This is completely free and responsive template can be customized to fit any industry's need.This template is mobile 
and retina/hi-dpi ready which means your site will look awesome, crisp and sharp on any screen resolutions and devices. 
Also, the code behind this is clean and well organized which makes the template very easy to customize.

==================================================================================================

-----------------------------------------------------------------------------------------------------

LICENSE:
This template (SQE Creative Business website Template) is released under the Creative Commons Attribution 4.0 License
(https://gecdesigns.com/free-template-license). This means that you are free:

   to Share - to copy, distribute, display, and perform the work
   to Remix - to make derivative works
   to make commercial use of the work 

Under the following conditions:

   Attribution - You must attribute the work in the manner specified by the 
   author or licensor (but not in any way that suggests that they endorse you 
   or your use of the work). 

   For any reuse or distribution, you must make clear to others the license 
   terms of this work

   Any of these conditions can be waived if you get permission from the 
   copyright holder (https://gecdesigns.com/)

Attribution: 
	
   You must include a credit link to our website(https://gecdesigns.com/) somewhere on
   your site. We prefer the footer credit that comes with the template but you are still 
   free to move it somewhere else.

-----------------------------------------------------------------------------------------------------

REMOVING THE LINK:

We understand that there are situations where you want to use the template without the crediting obligation. 
If that's your case, you can always send us a credit removal fee of 10 USD through Paypal.
This will allow you to use the template attribution/credit link free on ONE DOMAIN name.

Checkout the "Remove backlink" option available in template download page.

If possible, kindly send us the site url where the template is being used. Also, keep your Paypal receipt 
as proof of payment and your good to go.

------------------------------------------------------------------------------------------------------ 

SUPPORT:
    
Since This Template by GEC Designs is distributed for free, support is not offered. This Template is coded according 
to current web standards and we did our best to make the template easy to use and modify.
If you have minimum web development experience, you can easily modify the template. 
However, If you're still new to HTML and CSS, Please contact us to hire one on one guidance.
Site address (https://gecdesigns.com/)


------------------------------------------------------------------------------------------------------ 

GET THE LATEST VERSION:

We update our templates on a regular basis so to make sure that you have the latest version, 
always download the template files directly at our website(https://gecdesigns.com/) and register with us for the update.

-------------------------------------------------------------------------------------------------------

SOURCES AND CREDITS:

We've used the following resources as listed.

Fonts:
https://fonts.googleapis.com/css?family=Basic|Kreon|Roboto

Icons:
 - Font Awesome (https://fontawesome.com/v4.7.0/get-started/)

Free Stock Photos and Graphics:
 - Pixabay.com (https://pixabay.com/)
 - Pexels.com (https://www.pexels.com/)
 - Snipstock (https://www.snipstock.com/)
 
Javascript Files:

 - Bootstrap - https://getbootstrap.com
 - Jquery-3.3.1 - https://code.jquery.com/jquery-3.3.1.min.js
 - Owl carousel - https://github.com/OwlCarousel2/OwlCarousel2
 - Jquery-countTo - https://github.com/mhuggins/jquery-countTo
 - Filterizr - https://github.com/giotiskl/filterizr
 - Popper - https://unpkg.com/popper.js
 - ScrollIt - https://github.com/cmpolis/scrollIt.js
 - Validator - https://github.com/validatorjs/validator.js
 - Waypoints - https://gist.github.com/stanruss/2270a9a381f4e8623089
 - Lightbox - https://github.com/lokesh/lightbox2

-------------------------------------------------------------------------------------------------------

Thanks for downloading from gecdesigns:)